import java.util.Scanner;

public class Denominations {
    public static void denoms(double x){
        int oneK = (int) x / 1000;
        x %= 1000;
        int fiveH = (int) x / 500;
        x %= 500;
        int twoH = (int) x / 200;
        x %= 200;
        int oneH = (int) x / 100;
        x %= 100;
        int fifty = (int) x / 50;
        x %= 50;
        int twenty = (int) x / 20;
        x %= 20;
        int ten = (int) x / 10;
        x %= 10;
        int five = (int) x / 5;
        x %= 5;
        int one = (int) x / 1;
        x %= 1;
        int tfC = (int) (x / 0.25);
        x %= 0.25;
        int fC = (int) (x / 0.05);
        x %= 0.05;
        int oC = (int) (x / 0.01);
        x %= 0.01;

        System.out.println("No. of P 1000 bill: \t" + oneK);
        System.out.println("No. of P  500 bill: \t" + fiveH);
        System.out.println("No. of P  200 bill: \t" + twoH);
        System.out.println("No. of P  100 bill: \t" + oneH);
        System.out.println("No. of P   50 bill: \t" + fifty);
        System.out.println("No. of P   20 bill: \t" + twenty);
        System.out.println("No. of P   10 coin: \t" + ten);
        System.out.println("No. of P    5 coin: \t" + five);
        System.out.println("No. of P    1 coin: \t" + one);
        System.out.println("No. of P   25 cent: \t" + tfC);
        System.out.println("No. of P    5 cent: \t" + fC);
        System.out.println("No. of P    1 cent: \t" + oC);
    }

    public static void main(String[] args) {
        Scanner eeban = new Scanner(System.in);

        System.out.print("Enter amount: ");
        double amount = eeban.nextDouble();

        denoms(amount);

        eeban.close();
    }
}
