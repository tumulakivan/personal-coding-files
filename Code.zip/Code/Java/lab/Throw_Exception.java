// TUMULAK, IVAN STEIVEN A. - ACTIVITY 38

public class Throw_Exception {
    public void compute(int num1, int num2) {
        if(num2 < 1) throw new ArithmeticException("You cannot divide a number by zero.");
        else {
            int res = num1 / num2;
            System.out.println("The quotient of " + num1 + " and " + num2 + " is: " + res);
        }
    }

    public static void main(String[] args) {
        Throw_Exception te = new Throw_Exception();

        te.compute(5, 0);
    }
}