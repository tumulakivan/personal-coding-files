import java.io.*;
import java.util.*;

public class JavaFileReader {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int ctr = 0;

        do {
            System.out.println("Press 1 to read from a file");
            System.out.println("Press 2 to write to a file");
            System.out.println("Press 3 to exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();

            switch(choice) {
                case 1:
                    readFromFile();
                    break;
                case 2:
                    writeToFile();
                    break;
                case 3:
                    System.out.println("Exiting program.");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            }
        }while(ctr == 0);
    }

    private static void readFromFile() {
        try(BufferedReader reader = new BufferedReader(new FileReader("D:/Files/Code/Java/lab/highscore.txt"))) {
            String line;

            System.out.println("Contents of the file: ");
            while((line = reader.readLine()) != null) System.out.println(line);
        } catch(IOException e) {
            System.out.println("Error reading from the file: " + e.getMessage());
        }
    }

    private static void writeToFile() {
        try(BufferedWriter writer = new BufferedWriter(new FileWriter("D:/Files/Code/Java/lab/highscore.txt"))) {
            Scanner sc = new Scanner(System.in);
            String input;

            System.out.println("Enter text to write to the file (type 'exit' to stop).");

            while(!(input = sc.nextLine()).equalsIgnoreCase("exit")) {
                writer.write(input);
                writer.newLine();
            }
            System.out.println("Text written to the file.");
        } catch(IOException e) {
            System.out.println("Error writing to the file: " + e.getMessage());
        }
    }
}