class Rectangle {
    private float l;
    private float w;

    public Rectangle(){
        this.l = 0;
        this.w = 0;
    }

    public Rectangle(float l, float w){
        this.l = l;
        this.w = w;
    }

    public float getL(){
        return l;
    }

    public void setL(float l){
        this.l = l;
    }

    public float getW(){
        return w;
    }

    public void setW(float w){
        this.w = w;
    }

    public float getArea(){
        return l * w;
    }

    public float getPerimeter(){
        return 2 * (l + w);
    }
}
