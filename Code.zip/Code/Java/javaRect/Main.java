import java.util.Scanner;
import java.text.DecimalFormat;

public class Main{
    private static final DecimalFormat df = new DecimalFormat("0.00");

    public static void main(String[] args) {
        Scanner eeban = new Scanner(System.in);

        // first rectangle, default
        Rectangle defRect = new Rectangle();
        float l, w;
        System.out.print("Enter length: ");
        l = eeban.nextFloat();
        System.out.print("Enter width: ");
        w = eeban.nextFloat();
        System.out.println();

        defRect.setL(l);
        defRect.setW(w);
        System.out.println("defRect's length is: " + df.format(defRect.getL()));
        System.out.println("defRect's width is: " + df.format(defRect.getW()));
        System.out.println("defRect's area is: " + df.format(defRect.getArea()));
        System.out.println("defRect's perimeter is: " + df.format(defRect.getPerimeter()));
        
        // divider
        System.out.println();
        System.out.println("----------------------------------------");
        System.out.println();

        float length, width;
        System.out.print("Enter length: ");
        length = eeban.nextFloat();
        System.out.print("Enter width: ");
        width = eeban.nextFloat();
        Rectangle newRect = new Rectangle(length, width);
        System.out.println();

        System.out.println("newRect's length is: " + df.format(newRect.getL()));
        System.out.println("newRect's width is: " + df.format(newRect.getW()));
        System.out.println("newRect's area is: " + df.format(newRect.getArea()));
        System.out.println("newRect's perimeter is: " + df.format(newRect.getPerimeter()));

        eeban.close();
    }
}