public class AirlineTickets {
    private String passengerName;
    private String flightNumber;
    private String departureCity;
    private String arrivalCity;
    private double ticketPrice;
}
