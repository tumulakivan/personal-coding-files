import java.text.DecimalFormat;
import java.util.Scanner;

public class LoanInterest {
    double loan;
    double interest;

    private static final DecimalFormat df = new DecimalFormat(",###.00");

    LoanInterest(double loan, double interest) {
        this.loan = loan;
        this.interest = interest;
    }

    public static void computeInterest(LoanInterest li, double loan, double interest) {
        li.loan = loan;
        li.interest = interest;
        double total = loan * interest;
        System.out.println("Total Loan Interest is: " + df.format(total));
    }

    public static void main(String[] args) {
        double loan, interest;
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter loan amount: ");
        loan = sc.nextDouble();
        if (loan < 1.0) {
            System.out.println("Unacceptable value! loan amount cannot be below one.");
            System.exit(1);
        }

        System.out.print("Enter loan interest: ");
        interest = sc.nextDouble();
        if (interest < 0.0) {
            System.out.println("Unacceptable value! loan interest cannot be below zero.");
            System.exit(1);
        }

        LoanInterest li = new LoanInterest(loan, interest);
        computeInterest(li, loan, interest);

        sc.close();
    }
}
