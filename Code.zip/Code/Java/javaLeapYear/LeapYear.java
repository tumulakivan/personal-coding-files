import java.util.Scanner;

public class LeapYear {
    public static void leap(int x){
        if(x % 4 == 0 && x % 100 == 0 && x % 400 == 0)
            System.out.println("It is a leap year.");
        else if(x % 4 == 0 && x % 100 != 0)
            System.out.println("It is a leap year.");
        else if(x % 100 == 0 && x % 400 != 0)
            System.out.println("It is a leap year.");
        else
            System.out.println("It is not a leap year.");
    }

    public static void main(String[] args) {
        Scanner eeban = new Scanner(System.in);

        System.out.print("Enter year: ");
        int year = eeban.nextInt();

        leap(year);

        eeban.close();
    }
}
