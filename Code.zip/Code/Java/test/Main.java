import java.util.Scanner;

class Hero {
    private String name;
    private int level;
    private int experience;
    private double vitalityPoints;
    private double evasivenessPoints;
    private double spellPoints;
    private double attackDamage;

    public Hero(String name, double vitalityPoints, double evasivenessPoints, double spellPoints) {
        this.name = name;
        this.vitalityPoints = vitalityPoints;
        this.evasivenessPoints = evasivenessPoints;
        this.spellPoints = spellPoints;
        this.level = 1;
        this.experience = 0;
    }

    public void levelUp() {
        this.level++;
        this.vitalityPoints++;
        this.evasivenessPoints++;
        this.spellPoints++;
    }

    public int attack(int healthPoints) {
        int levelExperience = this.getLevel() * 1000;
        int currentLevel = this.getLevel();
        double hits = healthPoints / this.attackDamage;

        this.setExperience(healthPoints);
        while (this.getExperience() > levelExperience) {
            this.setExperience(this.getExperience() - levelExperience);
            this.setLevel(currentLevel++);
        }

        return (int) hits;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLevel() {
        return this.level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public int getExperience() {
        return this.experience;
    }

    public void setExperience(int experience) {
        this.experience = experience;
    }

    public double getVitalityPoints() {
        return this.vitalityPoints;
    }

    public void setVitalityPoints(double vitalityPoints) {
        this.vitalityPoints = vitalityPoints;
    }

    public double getEvasivenessPoints() {
        return this.evasivenessPoints;
    }

    public void setEvasivenessPoints(double evasivenessPoints) {
        this.evasivenessPoints = evasivenessPoints;
    }

    public double getSpellPoints() {
        return this.spellPoints;
    }

    public void setSpellPoints(double spellPoints) {
        this.spellPoints = spellPoints;
    }

    public double getAttackDamage() {
        return this.attackDamage;
    }

    public void setAttackDamage(double attackDamage) {
        this.attackDamage = attackDamage;
    }
}

class Brute extends Hero {
    public Brute(double vitalityPoints, double evasivenessPoints, double spellPoints) {
        super("Brute", vitalityPoints, evasivenessPoints, spellPoints);
    }

    @Override
    public void levelUp() {
        this.setVitalityPoints(this.getVitalityPoints() + 5);
        this.setEvasivenessPoints(this.getEvasivenessPoints() + 0.5);
        this.setSpellPoints(this.getSpellPoints() + 0.5);
    }

    @Override
    public void setAttackDamage(double attackDamage) {
        double attack = this.getLevel() * this.getVitalityPoints() + 500;
        super.setAttackDamage(attack);
    }
}

class Champion extends Hero {
    public Champion(double vitalityPoints, double evasivenessPoints, double spellPoints) {
        super("Champion", vitalityPoints, evasivenessPoints, spellPoints);
    }

    @Override
    public void levelUp() {
        this.setVitalityPoints(this.getVitalityPoints() + 2);
        this.setEvasivenessPoints(this.getEvasivenessPoints() + 3.5);
        this.setSpellPoints(this.getSpellPoints() + 1);
    }

    @Override
    public void setAttackDamage(double attackDamage) {
        double attack = this.getLevel() * this.getEvasivenessPoints() * 2
                * (this.getSpellPoints() + this.getVitalityPoints());
        super.setAttackDamage(attack);
    }
}

class Magus extends Hero {
    public Magus(double vitalityPoints, double evasivenessPoints, double spellPoints) {
        super("Magus", vitalityPoints, evasivenessPoints, spellPoints);
    }

    @Override
    public void levelUp() {
        this.setVitalityPoints(this.getVitalityPoints() + 2);
        this.setEvasivenessPoints(this.getEvasivenessPoints() + 3.5);
        this.setSpellPoints(this.getSpellPoints() + 1);
    }

    @Override
    public void setAttackDamage(double attackDamage) {
        double attack = this.getLevel() * Math.pow(2, Math.floor(this.getSpellPoints() / 2))
                + 5 * this.getEvasivenessPoints();
        super.setAttackDamage(attack);
    }
}

public class Main {
    public static void main(String[] args) {
        int choice;
        double vitality, evasiveness, spell;
        Scanner sc = new Scanner(System.in);

        System.out.println("class: ");
        choice = sc.nextInt();
        System.out.println("vitality: ");
        vitality = sc.nextDouble();
        System.out.println("evasivenesS: ");
        evasiveness = sc.nextDouble();
        System.out.println("spell: ");
        spell = sc.nextDouble();

        switch (choice) {
            case 1:
                Hero someHero = new Brute(vitality, evasiveness, spell);

                System.out.println("initial level: " + someHero.getLevel());
                System.out.println("initial exp: " + someHero.getExperience());
                System.out.println("damage: " + someHero.getAttackDamage());
                System.out.println("attacks needed for 1k hp: " + someHero.attack(1000));
                System.out.println("exp after attack: " + someHero.getExperience());
                break;
            default:
                System.out.println("invalid");
                break;
        }

        sc.close();
    }
}