package TimeWaste;

public class Main {

    public static void main(String[] args) {
        // Hey there, start typing your Java code here...

        // NOTE: Uncomment the line below when you want to submit your solution already
        Tester.test();
    }
}