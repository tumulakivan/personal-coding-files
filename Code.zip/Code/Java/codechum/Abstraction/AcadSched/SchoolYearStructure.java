package AcadSched;
@SuppressWarnings("deprecation")

import java.util.Date;

public class SchoolYearSchedule {

    public int dateDiff(Date date1, Date date2) {
        // INSERT UTILITY METHOD HERE
    }
}