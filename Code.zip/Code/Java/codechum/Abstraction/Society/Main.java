import java.util.*;

public class Main {
    public static void main(String args[]) {

        Father father = new Father();
        Mother mother = new Mother();
        Son son = new Son();

        // NOTE: Uncomment the line below when you want to submit your solution already
        Tester.test(father, mother, son);
    }
}