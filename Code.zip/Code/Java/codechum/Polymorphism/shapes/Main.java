package shapes;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class Main {

    public static void main(String[] args) {
        // Test Rectangle with multiple test cases
        testShape(new Rectangle(5.0, 4.0));
        testShape(new Rectangle(7.0, 3.0));
        testShape(new Rectangle(6.5, 4.5));

        // Test Triangle with multiple test cases
        testShape(new Triangle(3.0, 4.0, 5.0));
        testShape(new Triangle(5.0, 12.0, 13.0));
        testShape(new Triangle(7.0, 24.0, 25.0));

        // Test Square with multiple test cases
        testShape(new Square(6.0));
        testShape(new Square(8.0));
        testShape(new Square(4.5));

        // Check if fields in Rectangle, Triangle, and Square are private
        testFieldPrivacy(Rectangle.class);
        testFieldPrivacy(Triangle.class);
        testFieldPrivacy(Square.class);

        // Test if Shape is an abstract class
        testIfClassIsAbstract(Shape.class);

        // Test polymorphism
        testPolymorphism();
    }

    private static void testShape(Shape shape) {
        System.out.println("Testing " + shape.getClass().getSimpleName() + ":");
        System.out.println("Area: " + shape.getArea());
        System.out.println("Perimeter: " + shape.getPerimeter());
        System.out.println();
    }

    private static void testFieldPrivacy(Class<?> clazz) {
        Field[] fields = clazz.getDeclaredFields();
        boolean allFieldsPrivate = true;

        for (Field field : fields) {
            if (!Modifier.isPrivate(field.getModifiers())) {
                allFieldsPrivate = false;
                System.out.println("Field '" + field.getName() + "' in " + clazz.getSimpleName() + " is not private");
            }
        }

        if (allFieldsPrivate) {
            System.out.println("All fields in " + clazz.getSimpleName() + " are private");
        } else {
            System.out.println("Not all fields in " + clazz.getSimpleName() + " are private");
        }
        System.out.println();
    }

    private static void testIfClassIsAbstract(Class<?> clazz) {
        boolean isAbstract = Modifier.isAbstract(clazz.getModifiers());
        System.out.println(clazz.getSimpleName() + " is abstract: " + isAbstract);
        System.out.println();
    }

    private static void testPolymorphism() {
        Shape[] shapes = new Shape[] {new Rectangle(5.0, 4.0), new Triangle(3.0, 4.0, 5.0), new Square(6.0)};

        System.out.println("Testing Polymorphism:");
        for (Shape shape : shapes) {
            System.out.println(shape.getClass().getSimpleName() + " - Area: " + shape.getArea() + ", Perimeter: " + shape.getPerimeter());
        }
        System.out.println();
    }
}