package shapes;

import java.util.ArrayList;

public class ShapeCollection {
    private ArrayList<Shape> shapes;

    public ShapeCollection(ArrayList<Shape> shapes) {
        this.shapes = shapes;
    }

    public void calculateAndPrintAreaAndPerimeter() {
        for(Shape shape : shapes) {
            double area = shape.getArea();
            double perimeter = shape.getPerimeter();

            System.out.println("Area: " + String.format("%.2f", area) + "\nPerimeter: " + String.format("%.2f", perimeter) + "\n");
        }
    }
}