package gui;

public class PasswordField {
    public void validate(String password, PasswordInputElement passwordInputElement) {

    }
}