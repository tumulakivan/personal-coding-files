package gui;

public class InputElement {
    private int maxLength;
    private String value;

    public InputElement(String maxLength) {
        this.maxLength = maxLength;
        this.value = "";
    }

    public String getValue() {
        return this.value;
    }

    public void setValue(char c) {
        String newValue;
        
        if(c == '/') {
            newValue = this.value + c;
            return newValue;
        } else {
            String currentValue = this.getValue();
            StringBuilder builder = new StringBuilder(currentValue);
            builder.deleteCharAt(currentValue.length() - 1);
            newValue = builder.toString();
            return newValue;
        }
    }

    public boolean validate() {
        String eval = this.value;

        if(eval.length() > 0 && eval.length() < maxLength) return true;

        return false;
    }
}

class PasswordInputElement extends InputElement {
    private char[] allowedCharacters;

    public PasswordInputElement(int maxLength, char[] allowedCharacters) {
        this.maxLength = maxLength;
        this.allowedCharacters = allowedCharacters;
    }

    @Override
    public boolean validate() {
        String eval = this.getValue();

        for(int ctr1 = 0; ctr1 < eval.length(); ctr1++) {
            for(int ctr2 = 0; ctr2 < eval.length(); ctr2++) {
                if(eval.charAt(ctr1) != this.allowedCharacters[ctr2]) return false;
            }
        }

        return true;
    }
}

class CustomPasswordInputElement extends PasswordInputElement {
    public CustomPasswordInputElement(int maxLength) {
        this.maxLength = maxLength;
        this.allowedCharacters = {'J', 'r', 'v', 'D'};
    }
}