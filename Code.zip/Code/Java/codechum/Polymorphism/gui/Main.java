package gui;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class Main {

    public static void main(String[] args) {
        // Test InputElement class
        InputElement inputElement = new InputElement(10);
        testInputElement(inputElement);

        // Test PasswordInputElement class
        char[] allowedChars = {'a', 'b', 'c', '1', '2', '3'};
        PasswordInputElement passwordElement = new PasswordInputElement(10, allowedChars);
        testPasswordInputElement(passwordElement);

        // Test CustomPasswordInputElement class
        CustomPasswordInputElement customPasswordElement = new CustomPasswordInputElement(10);
        testPasswordInputElement(customPasswordElement);

        // Check if fields in InputElement and PasswordInputElement are private
        testFieldPrivacy(InputElement.class);
        testFieldPrivacy(PasswordInputElement.class);

        // Test polymorphism
        testPolymorphism();

        testPasswordField();
    }

    private static void testInputElement(InputElement element) {
        System.out.println("Testing InputElement:");
        element.setValue('a');
        element.setValue('b');
        System.out.println("Value: " + element.getValue());
        System.out.println("Validation: " + element.validate());
        element.setValue('/'); // Deleting last character
        System.out.println("Value after delete: " + element.getValue());
        System.out.println();
    }

    private static void testPasswordInputElement(PasswordInputElement element) {
        System.out.println("Testing " + element.getClass().getSimpleName() + ":");
        element.setValue('a');
        element.setValue('1');
        System.out.println("Value: " + element.getValue());
        System.out.println("Validation: " + element.validate());
        element.setValue('x'); // Invalid character for PasswordInputElement
        System.out.println("Value after adding invalid character: " + element.getValue());
        System.out.println("Validation after invalid character: " + element.validate());
        System.out.println();
    }

    private static void testFieldPrivacy(Class<?> clazz) {
        Field[] fields = clazz.getDeclaredFields();
        boolean allFieldsPrivate = true;

        for (Field field : fields) {
            if (!Modifier.isPrivate(field.getModifiers())) {
                allFieldsPrivate = false;
                System.out.println("Field '" + field.getName() + "' in " + clazz.getSimpleName() + " is not private");
            }
        }

        if (allFieldsPrivate) {
            System.out.println("All fields in " + clazz.getSimpleName() + " are private");
        } else {
            System.out.println("Not all fields in " + clazz.getSimpleName() + " are private");
        }
        System.out.println();
    }

    private static void testPolymorphism() {
        InputElement[] elements = new InputElement[] {
            new InputElement(10),
            new PasswordInputElement(10, new char[] {'a', 'b', 'c', '1', '2', '3'}),
            new CustomPasswordInputElement(10)
        };

        System.out.println("Testing Polymorphism:");
        for (InputElement element : elements) {
            System.out.println("Testing " + element.getClass().getSimpleName() + ":");
            element.setValue('a');
            element.setValue('b');
            System.out.println("Value: " + element.getValue());
            System.out.println("Validation: " + element.validate());
            element.setValue('/');
            System.out.println("Value after delete: " + element.getValue());
            System.out.println();
        }
    }

    private static void testPasswordField() {
        System.out.println("Testing PasswordField:");

        // Example password and element to test
        String testPassword = "abc123";
        char[] allowedChars = {'a', 'b', 'c', '1', '2', '3'};
        PasswordInputElement passwordElement = new PasswordInputElement(10, allowedChars);

        PasswordField passwordField = new PasswordField();
        passwordField.validate(testPassword, passwordElement); // Testing with the provided password and element
        System.out.println();

        CustomPasswordInputElement customPasswordInputElement = new CustomPasswordInputElement(5);
        passwordField.validate(testPassword, customPasswordInputElement);
    }
}