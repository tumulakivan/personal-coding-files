package pets;

import java.util.ArrayList;

abstract class Pet {
    private String type;
    private boolean isFriendly;

    public Pet(String type, boolean isFriendly) {
        this.type = type;
        this.isFriendly = isFriendly;
    }

    public String getType() {
        return this.type;
    }

    public boolean getIsFriendly() {
        return this.isFriendly;
    }

    abstract public void makeNoise();

    @Override
    public String toString() {
        if(!this.isFriendly) return "Pet " + this.type + " is not friendly";
        return "Pet " + this.type + " is friendly";
    }
}

class Cat extends Pet {
    public Cat() {
        super("cat", true);
    }

    @Override
    public void makeNoise() {
        System.out.println("Meow!");
    }
}

class Lion extends Pet {
    public Lion() {
        super("lion", false);
    }

    @Override
    public void makeNoise() {
        System.out.println("Roar!");
    }
}

class Dog extends Pet {
    private String breed;

    public Dog(String breed) {
        super("dog", true);
        this.breed = breed;
    }

    @Override
    public void makeNoise() {
        System.out.println("Arf!");
    }

    @Override
    public String toString() {
        if(!this.getIsFriendly()) return "Pet " + this.getType() + " is not friendly [" + this.breed + "]";

        return "Pet " + this.getType() + " is friendly [" + this.breed + "]";
    }
}

class PetHouse {
    public void makeNoise(ArrayList<Pet> pets) {
        for (Pet pet : pets) {
            pet.makeNoise();
        }
    }
}