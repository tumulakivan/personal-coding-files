package pets;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        // Test Cat class
        Cat cat = new Cat();
        testPet(cat);

        // Test Lion class
        Lion lion = new Lion();
        testPet(lion);

        // Test Dog class
        Dog dog = new Dog("Golden Retriever");
        testPet(dog);

        // Check if fields in Pet, Dog are private
        testFieldPrivacy(Pet.class);
        testFieldPrivacy(Dog.class);

        // Test if Pet is an abstract class
        testIfClassIsAbstract(Pet.class);

        // Test polymorphism
        testPolymorphism();
    }

    private static void testPet(Pet pet) {
        System.out.println("Testing " + pet.getClass().getSimpleName() + ":");
        System.out.println(pet);
        pet.makeNoise();
        System.out.println();
    }

    private static void testFieldPrivacy(Class<?> clazz) {
        Field[] fields = clazz.getDeclaredFields();
        boolean allFieldsPrivate = true;

        for (Field field : fields) {
            if (!Modifier.isPrivate(field.getModifiers())) {
                allFieldsPrivate = false;
                System.out.println("Field '" + field.getName() + "' in " + clazz.getSimpleName() + " is not private");
            }
        }

        if (allFieldsPrivate) {
            System.out.println("All fields in " + clazz.getSimpleName() + " are private");
        } else {
            System.out.println("Not all fields in " + clazz.getSimpleName() + " are private");
        }
        System.out.println();
    }

    private static void testIfClassIsAbstract(Class<?> clazz) {
        boolean isAbstract = Modifier.isAbstract(clazz.getModifiers());
        System.out.println(clazz.getSimpleName() + " is abstract: " + isAbstract);
        System.out.println();
    }

    private static void testPolymorphism() {
        ArrayList<Pet> pets = new ArrayList<>();
        pets.add(new Cat());
        pets.add(new Lion());
        pets.add(new Dog("Beagle"));

        PetHouse petHouse = new PetHouse();
        System.out.println("Testing Polymorphism with PetHouse:");
        petHouse.makeNoise(pets);
        System.out.println();
    }
}