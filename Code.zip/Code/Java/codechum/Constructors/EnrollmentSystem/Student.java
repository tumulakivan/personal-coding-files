public class Student {
    String name;

    Student(String name) {
        this.name = name;
    }
}
