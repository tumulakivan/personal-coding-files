public class Section {
    String name;

    Section(String name) {
        this.name = name;
    }
}
