import java.util.Scanner;

public class Main {
    public static void BooBaa(int x){
        int size = x;

        for(int i = 1; i <= size; i++){
            if(i != size){
                if(i % 3 == 0 && i % 5 == 0)
                    System.out.print("BooBaa, ");
                else if(i % 5 == 0)
                    System.out.print("Baa, ");
                else if(i % 3 == 0)
                    System.out.print("Boo, ");
                else
                    System.out.print(i + ", ");
            }
            else{
                if(i % 3 == 0 && i % 5 == 0)
                    System.out.print("BooBaa");
                else if(i % 5 == 0)
                    System.out.print("Baa");
                else if(i % 3 == 0)
                    System.out.print("Boo");
                else
                    System.out.print(i);
            }
        }
    }

    public static void main(String[] args) {
        Scanner eeban = new Scanner(System.in);

        System.out.print("Enter integer: ");
        int x = eeban.nextInt();

        BooBaa(x);

        eeban.close();
    }
}
