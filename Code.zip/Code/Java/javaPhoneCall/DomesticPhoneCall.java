import java.util.Scanner;
import java.text.DecimalFormat;

public class DomesticPhoneCall {
    private static final DecimalFormat df = new DecimalFormat("0.00");

    public static double charge(int min){
        double total = 0;

        if(min <= 3)
            total += 20.85;
        else if(min == 0){
            return total;
        }
        else
            total += (min-3) * 6.25 + 20.85;

        return total;
    }

    public static void main(String[] args) {
        Scanner eeban = new Scanner(System.in);

        System.out.print("Enter minutes of call: ");
        int min = eeban.nextInt();

        System.out.print("The total charge is " + df.format(charge(min)));
        
        eeban.close();
    }
}