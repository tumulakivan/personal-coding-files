/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javaactivity;

/**
 *
 * @author L15Y13W03
 */
public class Activity20 {
    public static void main(String[] args){
        int[][] matrix = new int[3][4];
        matrix[0][0] = 1;
        matrix[1][2] = 5;
        int element = matrix[0][0];
        System.out.println("Element: " + element);
    }
}
