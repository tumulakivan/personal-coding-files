/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javaactivity;

/**
 *
 * @author L15Y13W03
 */
public class Activity2 {
    public static void main(String args[]){
        System.out.println("** **     **    ***    **     **");
        System.out.println("** **     **   ** **   ****   **");
        System.out.println("**  **   **   **   **  ** **  **");
        System.out.println("**  **   **  ********* **  ** **");
        System.out.println("**  **   **  ********* **  ** **");
        System.out.println("**   ** **   **     ** **   ****");
        System.out.println("**    ***    **     ** **     **");
        System.out.println();
        System.out.println("****   ****** **     **   ********  ");
        System.out.println("*****  ****** ****   **  ***        ");
        System.out.println("**  ** **     ** **  ** **     ***  ");
        System.out.println("****** ****   **  ** ** **       ***");
        System.out.println("****   **     **  ** **  ***     ** ");
        System.out.println("**     ****** **   ****   ********  ");
        System.out.println("**     ****** **     **     *****   ");
        System.out.println();
    }
}
