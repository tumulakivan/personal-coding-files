public class Activity23 {
    static void printMessage(){
        System.out.println("Hello, this is a void method.");
    }
    
    static void displayName(){
        System.out.println("Hi! My name is- What? My name is- Who? My name is- chkchkchkc Slim Shady.");
    }
    
    public static void main(String[] args){
        printMessage();
        displayName();
    }
}
