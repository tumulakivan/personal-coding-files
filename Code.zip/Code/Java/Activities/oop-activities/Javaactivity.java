/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javaactivity;

/**
 *
 * @author L15Y13W03
 */
public class Javaactivity {

    public static void main(String[] args) {
        System.out.println("Ivan Steiven A. Tumulak");
        System.out.println("IT ROCKS!");
    }
}
