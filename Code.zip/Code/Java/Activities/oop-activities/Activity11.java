/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javaactivity;

/**
 *
 * @author L15Y13W03
 */
public class Activity11 {
    public static void main(String[] args){
        int n = 3;
        int i = 1;
        while(i <= n){
            System.out.println("The number is " + i);
            i++;
        }
    }
}
