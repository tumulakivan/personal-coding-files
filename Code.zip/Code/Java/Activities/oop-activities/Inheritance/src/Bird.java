public class Bird extends Dog {

}