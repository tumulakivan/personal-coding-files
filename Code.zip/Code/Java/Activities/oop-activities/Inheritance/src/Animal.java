public class Animal {
    public void Abunda(){

    }

    public void display(){
        System.out.println("I am a parent class.");
    }
}
