public class Cat extends Dog{

}