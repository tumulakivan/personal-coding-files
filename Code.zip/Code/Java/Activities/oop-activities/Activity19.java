/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javaactivity;

/**
 *
 * @author L15Y13W03
 */
public class Activity19 {
    public static void main(String[] args){
        String[] words = {"I", "Love", "You"};
        
        for(int i = 0; i < words.length; i++)
            System.out.print(words[i] + " ");
    }
}
