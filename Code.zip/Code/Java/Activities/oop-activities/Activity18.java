/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.javaactivity;

/**
 *
 * @author L15Y13W03
 */
public class Activity18 {
    public static void main(String[] args){
        int[] numbers = new int[5];
        numbers[0] = 10;
        numbers[1] = 20;
        int sum = numbers[0] + numbers[1];
        System.out.println("Sum: " + sum);
    }
}
