void displayString(char word[]);
int countAs(char word[]);
int isPalindrome(char word[]);
