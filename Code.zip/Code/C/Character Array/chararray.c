#include <stdio.h>

void displayString(char word[]){
	int i;
	for(i=0;word[i]!='\0';i++)
		printf("%c ",word[i]);
}

int countAs(char word[]){
	int i,count=0;
	for(i=0;word[i]!='\0';i++){
		if(word[i]=='a' || word[i]=='A')
			count++;
	}
	return count;
}

int countString(char word[]){
	int i, ctr=0;
	for(i=0;word[i]!='\0';i++)
		ctr++;
	return ctr;
}

int isPalindrome(char word[]){
	int i,count=countString(word), ans=1;
	for(i=0;i<=count/2;i++){
		if(word[i]!=word[count-1-i]){
			ans=0;
			break;
		}
	}
	return ans;
}

