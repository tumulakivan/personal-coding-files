#include <stdio.h>
#include <stdlib.h>
#define SIZE 50

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char word1[SIZE];

	gets(word1);
	printf("\nLength of word: %d\n",countString(word1));
	printf("\nPalindrome?: %d\n",isPalindrome(word1));
	//displayString(word1);
	//printf("%s",word1);
	//printf("\nNumber of As: %d\n",countAs(word1));
	return 0;
}
