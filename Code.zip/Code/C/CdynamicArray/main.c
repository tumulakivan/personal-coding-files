#include <stdio.h>
#include <stdlib.h>
#include "dynArr.h"

int main()
{
    int *arr, size, item, count = 0;

    printf("Enter size of the array: ");
    scanf("%d", &size);

    arr = (int *)malloc(size * sizeof(int));

    int i;
    for (i = 0; i < size; i++)
    {
        printf("Index #%d: ", i + 1);
        scanf("%d", &item);
        add(arr, &count, item);
    }

    print(arr, size);
    free(arr);
    // for good practice, set the array to NULL after it is deallocated
    arr = NULL;
    print(arr, size);

    return 0;
}