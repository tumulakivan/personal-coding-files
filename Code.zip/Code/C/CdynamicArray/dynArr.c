#include <stdio.h>
#include <stdlib.h>
#include "dynArr.h"

void add(int *arr, int *count, int item)
{
    arr[*count] = item;
    (*count)++;
}

void print(int *arr, int size)
{
    int i;

    for (i = 0; i < size; i++)
    {
        if (arr == NULL)
        {
            printf("Invalid. Memory has been deallocated.");
            break;
        }
        else
            printf("%d ", (*arr + i));
    }
    printf("\n");
}