#ifndef __DYNARR_H_
#define __DYNARR_H_

void add(int *arr, int *count, int item);
void print(int *arr, int size);

#endif