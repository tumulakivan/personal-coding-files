#include <stdio.h>
#include <stdlib.h>
#include "array1.h"
#define size 6

void initArray(int arr[]){
    int i;

    for(i = 0; i < size; i++)
        arr[i] = 0;
}

void display(int arr[]){
    int i;

    for(i = 0; i < size; i++)
        printf("%d ", arr[i]);

    printf("\n");
}

int highest(int arr[]){
    int high = arr[0], i;

    for(i = 1; i < size; i++){
        if(arr[i] > high)
            high = arr[i];
    }

    return high;
}

int lowest(int arr[]){
    int low = arr[0], i;

    for(i = 1; i < size; i++){
        if(arr[i] < low)
            low = arr[i];
    }

    return low;
}

float mid(int arr[]){
    
}