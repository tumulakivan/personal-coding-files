#ifndef CIRCLE_H_
#define CIRCLE_H_

typedef struct{
    int x;
    int y;
}Point;

typedef struct{
    Point center;
    float radius;
}Circle;

float diameter(Circle c);
float area(Circle c);
float circumference(Circle c);

#endif