#include <stdio.h>
#include "Circle.h"

float diameter(Circle c){
    return c.radius * 2;
}

float area(Circle c){
    return 3.14 * (c.radius * c.radius);
}

float circumference(Circle c){
    return 2 * 3.14 * c.radius;
}