#include <stdio.h>
#include "Circle.h"
#include "Circle.c"

int main(){
    Circle c;

    //initialize center of circle to (0,0)
    c.center.x = 0;
    c.center.y = 0;

    printf("Center of circle is: ");
    printf("(%d,%d)", c.center.x, c.center.y);

    printf("\n\n");

    printf("Enter radius of circle: ");
    scanf("%f", &c.radius);
    printf("\n");

    printf("Diamater: %.2f\n", diameter(c));
    printf("Area: %.2f\n", area(c));
    printf("Circumference: %.2f\n", circumference(c));

    return 0;
}