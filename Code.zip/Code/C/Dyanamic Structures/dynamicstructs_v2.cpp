#include<stdio.h>
#include<stdlib.h>
typedef struct node{
	int data;
	struct node *next;
}node;
int main(){
	node *head=NULL;
	
	int choice, num;
	node *newNode, *curr;
	do{
		printf("1 - Add new node\n");
		printf("2 - Display\n");
		printf("3 - Exit\n");
		printf("Input choice:");
		scanf("%d",&choice);
		
		switch(choice){
			case 1:
					printf("Input number to add:");
					scanf("%d",&num);
					newNode =(node*)malloc(sizeof(node));
					newNode->data=num;
					
					if(head==NULL){
						newNode->next=head;
						head=newNode;
					}else{
						curr = head;
						while(curr->next!=NULL)
							curr =curr->next;
						newNode->next =curr->next;
						curr->next=newNode;
					}
					
					break;
			case 2:
					curr=head;
					while(curr!=NULL){
						printf("%d\n",curr->data);
						curr=curr->next;	
					}
					break;
		}
	}while(choice!=3);
	
}
