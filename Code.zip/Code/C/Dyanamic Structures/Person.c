#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Person{
	char name[100];
	int age;
	struct Person *next;
}Person;

int main(){
	Person *temp,*curr;
	Person *head=NULL;
	
	temp=(Person*)malloc(sizeof(Person));
	strcpy(temp->name,"Juan");
	temp->age=43;
		
	
	
	temp->next=head;
	head = temp;
		
	temp=(Person*)malloc(sizeof(Person));
	strcpy(temp->name,"Maria");
	temp->age=12;
	
	temp->next=head->next;
	head->next=temp;
	
	
	
	temp=(Person*)malloc(sizeof(Person));
	strcpy(temp->name,"John");
	temp->age=33;
	
	temp->next=head->next->next;
	head->next->next=temp;
	
	temp=(Person*)malloc(sizeof(Person));
	strcpy(temp->name,"John");
	temp->age=33;
	
	temp->next=head->next->next->next;
	head->next->next->next=temp;
	
	
	curr=head;
	while(curr!=NULL){
		printf("Name:%s\t",curr->name);
		printf("Age:%d\n",curr->age);
		curr=curr->next;
		
	}
	
	free(temp);
	
	
}
