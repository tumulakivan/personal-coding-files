#include<stdio.h>
#include<stdlib.h>
int main(){
	int *ptr;
	int n,x;

	n=3;	
	ptr =(int*)malloc(3*sizeof(int));
	
	for(x=0; x<n; x++)
		ptr[x]=x+1; //1 2 3

	for(x=0; x<n; x++)
		printf("%d\n", ptr[x]);
		
	ptr = realloc(ptr,10*(sizeof(int)));
	
	for(x=3; x<10; x++)
		ptr[x]=x+1;
	
	printf("\nReallocation\n");
	for(x=0; x<10; x++)
		printf("%d\n", ptr[x]);
	free(ptr+1);
	printf("%d",*ptr);
}
