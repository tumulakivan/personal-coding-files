#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Person{
	char name[100];
	int age;
	struct Person *next;
}Person;

int main(){
	Person *temp,*curr;
	Person *head=NULL;
	int choice;
	
	
	do{
		temp=(Person*)malloc(sizeof(Person));
		strcpy(temp->name,"Juan");
		temp->age=43;
	
		if(head==NULL){
			temp->next=head;
			head=temp;
		}else{
			curr=head;
			while(curr->next!=NULL)
				curr=curr->next;
			temp->next=curr->next;
			curr->next=temp;
			
		}
		scanf("%d",&choice);	
	
	}while(choice !=1);
	
	
	
	curr=head;
	while(curr!=NULL){
		printf("Name:%s\t",curr->name);
		printf("Age:%d\n",curr->age);
		curr=curr->next;
		
	}
	
	free(temp);
	
	
}
