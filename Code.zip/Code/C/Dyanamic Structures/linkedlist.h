typedef struct node{
	int data;
	struct node *next;
}node;

void display(node *head);
node* insertEnd(node *head, int num);
node* insertFront(node *head, int num);
node* insertBeforeANumber(node *head, int num, int pos);
int count(node *head);
int sum(node *head);
int search(node *head, int num);
