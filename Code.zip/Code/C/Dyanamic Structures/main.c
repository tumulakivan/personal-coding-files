#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	node *head=NULL;
	int choice, num, pos;
	do{
	printf("\n1 - Add new node at the front\n");
	printf("2 - Add new node at end\n");
	printf("3 - Display\n");
	printf("4 - Display number of nodes\n");
	printf("5 - Display sum\n");
	printf("6 - Add new node before a number\n ");
	printf("10 - Exit\n");
	printf("Input choice:");
	scanf("%d",&choice);
	
	switch(choice){
		case 1:
				printf("Input number to add:");
				scanf("%d",&num);
				head=insertFront(head,num);
				break;
		case 2:
				printf("Input number to add:");
				scanf("%d",&num);
				head=insertEnd(head,num);
				break;
		case 3:
				display(head);
				break;
		case 4:
				printf("Number of nodes: %d\n",count(head));
				break;
		case 5:
				printf("Sum: %d\n",sum(head));
				break;
		case 6: 
				printf("Input number to add:");
				scanf("%d",&num);
				printf("Input before what number:");
				scanf("%d",&pos);
				head = insertBeforeANumber(head, num,pos);
				break;
		}
	}while(choice!=10);
	return 0;
}
