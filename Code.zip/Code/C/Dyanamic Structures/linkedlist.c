#include <stdio.h>
#include <stdlib.h>
#include "linkedlist.h"

int search(node *head, int num)
{

	node *curr = head;
	while (curr != NULL)
	{
		if (curr->data == num)
			return 1;
		curr = curr->next;
	}
	return 0;
}

int count(node *head)
{
	int ctr = 0;
	node *curr = head;
	while (curr != NULL)
	{
		ctr++;
		curr = curr->next;
	}
	return ctr;
}

int sum(node *head)
{
	int sum = 0;
	node *curr = head;
	while (curr != NULL)
	{
		sum += curr->data;
		curr = curr->next;
	}
	return sum;
}

void display(node *head)
{
	node *curr = head;
	while (curr != NULL)
	{
		printf("%d\t", curr->data);
		curr = curr->next;
	}
	printf("\n");
}

node *insertEnd(node *head, int num)
{
	node *newNode, *curr;
	newNode = (node *)malloc(sizeof(node));
	newNode->data = num;

	if (head == NULL)
	{
		insertFront(head, num);
	}
	else
	{
		curr = head;
		while (curr->next != NULL)
			curr = curr->next;
		newNode->next = curr->next;
		curr->next = newNode;
	}
	return head;
}

node *insertFront(node *head, int num)
{
	node *newNode, *curr;
	newNode = (node *)malloc(sizeof(node));
	newNode->data = num;

	newNode->next = head;
	head = newNode;

	return head;
}

node *insertBeforeANumber(node *head, int num, int pos)
{
	node *curr = head;
	node *newNode;

	if (search(head, pos) == 0)
		printf("%d not existing.\n", pos);
	else
	{
		newNode = (node *)malloc(sizeof(node));
		newNode->data = num;
		if (curr->data == pos)
		{
			newNode->next = head;
			head = newNode;
		}
		else
		{
			while (curr->next->data != pos)
				curr = curr->next;
			newNode->next = curr->next;
			curr->next = newNode;
		}
	}
	return head;
}
