#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct Person{
	char name[100];
	int age;
	Person *next;
}Person;

int main(){
	Person *p1;
	
	p1=(Person*)malloc(sizeof(Person));
	
	if(p1!=NULL){
		strcpy(p1->name,"Juan");
		p1->age=43;
		printf("%s\n",p1->name);
		printf("%d\n",p1->age);
	}
	
}
