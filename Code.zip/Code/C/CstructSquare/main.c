#include <stdio.h>
#include "Rectangle.h"
#include "Rectangle.c"

int main(){
    Rectangle r;

    //set points of Rectangle
    r.upperLeft.x = -5;
    r.upperLeft.y = 4;
    r.lowerRight.x = 5;
    r.lowerRight.y = -4;
    //display(r);

    printf("Considering ");
    display(r);
    printf("Length: %d\n", length(r));
    printf("Width: %d\n", width(r));
    printf("Area: %d\n", area(r));
    printf("Perimeter: %d\n", perimeter(r));

    return 0;
}