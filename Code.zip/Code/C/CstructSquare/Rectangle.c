#include <stdio.h>
#include "Rectangle.h"

void display(Rectangle rec){
    printf("2 points of the Rectangle (upper left and lower right, respectively) are at (%d,%d) and (%d,%d):\n\n", rec.upperLeft.x, rec.upperLeft.y, rec.lowerRight.x, rec.lowerRight.y);
}

int length(Rectangle rec){
    return rec.upperLeft.y - rec.lowerRight.y;
}

int width(Rectangle rec){
    return rec.lowerRight.x - rec.upperLeft.x;
}

int area(Rectangle rec){
    return length(rec) * width(rec);
}

int perimeter(Rectangle rec){
    return 2 * (length(rec) + width(rec));
}