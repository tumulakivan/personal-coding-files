#ifndef RECTANGLE_H_
#define RECTANGLE_H_

typedef struct{
    int x;
    int y;
}Point;

typedef struct{
    Point upperLeft;
    Point lowerRight;
}Rectangle;

void display(Rectangle rec);
int length(Rectangle rec);
int width(Rectangle rec);
int area(Rectangle rec);
int perimeter(Rectangle rec);

#endif