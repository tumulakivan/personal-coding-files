#ifndef BIRTHDAY_H_
#define BIRTHDAY_H_

struct Birthday{
    int month;
    int day;
    int year;
};

struct Person{
    char name[50];
    struct Birthday birthdate;
};

void setName(struct Person *dzai);
void display(struct Person *dzai);
void setBday(struct Person *dzai);

#endif