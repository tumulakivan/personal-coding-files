#include <stdio.h>
#include <stdlib.h>
#include "birthday.h"
#include "birthday.c"

int main(int argc, char *argv[]){
    char name[50];
    int day, month, year;
    struct Person dzai;

    setName(&dzai);
    display(&dzai);

    return 0;
}