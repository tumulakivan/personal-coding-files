#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "birthday.h"

void setName(struct Person *dzai){
    printf("Enter your name: ");
    gets(dzai->name);
}

void display(struct Person *dzai){
    printf("Name: ", dzai->name);
}