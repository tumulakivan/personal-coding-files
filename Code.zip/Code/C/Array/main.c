#include <stdio.h>
#include <stdlib.h>
#include "array.h"
#define SIZE 10

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int num[SIZE];
	int count=0;
	
	add(num,&count,10);
	add(num,&count,6);
	add(num,&count,7);
	display(num,count);
	addFrontV1(num,&count,-3);
	display(num,count);
	addFrontV2(num,&count,25);
	display(num,count);
	addAtV1(num,&count,-6,3);
	display(num,count);
	addAtV1(num,&count,100,3);
	display(num,count);
	deleteEnd(&count);
	display(num,count);
	deleteFrontV1(num,&count);
	display(num,count);
	deleteFrontV2(num,&count);
	display(num,count);
	deleteAtV2(num,&count,2);
	display(num,count);
	//input(num,SIZE);
	//display(num,SIZE);
	//printf("Max = %d\n",findMax(num,SIZE));
	//printf("Min = %d\n",findMin(num,SIZE));
	//printf("Sum = %d\n",computeSum(num,SIZE));
	//printf("Number of positives = %d\n",countPos(num,SIZE));
	//printf("Number of negatives = %d\n",countNeg(num,SIZE));
	//printf("Even = %d\n",countEven(num,SIZE));
	//printf("Odd = %d\n",countOdd(num,SIZE));
	return 0;
}
