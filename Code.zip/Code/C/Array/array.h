void input(int num[], int size);
void display(int num[], int size);
int computeSum(int num[], int size);

int countPos(int num[], int size);
int countNeg(int num[], int size);
int countEven(int num[], int size);
int countOdd(int num[], int size);

int findItem(int num[], int size, int item);

int findMax(int num[], int size);
int findMin(int num[], int size);

void add(int num[], int *count, int item);
void addFrontV1(int num[], int *count, int item);
void addFrontV2(int num[], int *count, int item);
void addAtV1(int num[], int *count, int item, int pos);
void addAtV2(int num[], int *count, int item, int pos);

void deleteEnd(int *count);
void deleteFrontV1(int num[], int *count);
void deleteFrontV2(int num[], int *count);
void deleteAtV1(int num[], int *count, int pos);
void deleteAtV2(int num[], int *count, int pos);
