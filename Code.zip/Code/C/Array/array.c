#include <stdio.h>

void input(int num[], int size){
	int i;
	for(i=0;i<size;i++)
		scanf("%d",&num[i]);//input elements
}

void display(int num[], int size){
	int i;
	for(i=0;i<size;i++)
		printf("%d ",num[i]);//displays the elements
	printf("\n");
}

int computeSum(int num[], int size){
	int i,sum;
	sum = 0;
	for(i=0;i<size;i++)
		sum += num[i];//sum=sum+num[i];//computes for the sum
	return sum;
}

int countPos(int num[], int size){
	int i, count=0;
	for(i=0;i<size;i++){
		if(num[i]>=0)
			count++;
	}	
	return count;
}

int countNeg(int num[], int size){
	int i, count=0;
	for(i=0;i<size;i++){
		if(num[i]<0)
			count++;
	}	
	return count;
}

int countEven(int num[], int size){
	int i, count=0;
	for(i=0;i<size;i++){
		if(num[i]%2==0)
			count++;
	}	
	return count;
}

int countOdd(int num[], int size){
	int i, count=0;
	for(i=0;i<size;i++){
		if(num[i]%2!=0)
			count++;
	}	
	return count;
}

int findItem(int num[], int size, int item){
	int i, ans=0;//false
	for(i=0;i<size;i++){
		if(num[i]==item){
			ans=1;//true
			break;
		}
	}
	return ans;
}

int findMax(int num[], int size){
	int i,max=num[0];
	for(i=1;i<size;i++){
		if(num[i]>max)
			max =num[i];
	}
	return max;
}

int findMin(int num[], int size){
	int i,min=num[0];
	for(i=1;i<size;i++){
		if(num[i]<min)
			min =num[i];
	}
	return min;
}

void add(int num[], int *count, int item){
	num[(*count)++]=item;	
}

void addFrontV1(int num[], int *count, int item){
	int i;
	for(i=(*count)-1;i>=0;i--)
		num[i+1]=num[i];
	num[0]=item;
	(*count)++;
}

void addFrontV2(int num[], int *count, int item){
	int i;
	for(i=(*count);i>0;i--)
		num[i]=num[i-1];
	num[0]=item;
	(*count)++;
}

void addAtV1(int num[], int *count, int item, int pos){
	int i;
	for(i=(*count)-1;i>=pos;i--)
		num[i+1]=num[i];
	num[pos]=item;
	(*count)++;
}

void addAtV2(int num[], int *count, int item, int pos){
	int i;
	for(i=(*count);i>pos;i--)
		num[i]=num[i-1];
	num[pos]=item;
	(*count)++;
}

void deleteEnd(int *count){
	(*count)--;
}

void deleteFrontV1(int num[], int *count){
	int i;
	for(i=0;i<(*count)-1;i++)
		num[i]=num[i+1];
	(*count)--;
}

void deleteFrontV2(int num[], int *count){
	int i;
	for(i=1;i<*count;i++)
		num[i-1]=num[i];
	(*count)--;
}

void deleteAtV1(int num[], int *count, int pos){
	int i;
	for(i=pos;i<(*count)-1;i++)
		num[i]=num[i+1];
	(*count)--;
}

void deleteAtV2(int num[], int *count, int pos){
	int i;
	for(i=pos+1;i<*count;i++)
		num[i-1]=num[i];
	(*count)--;
}
