#include <stdio.h>
#include "prac.h"
#include "prac.c"

int main(int argc, char *argv[]){
    int arr[SIZE] = {0};
    int count = 0;
    int item;

    scanf("%d", &item);
    add(arr, &count, item);
    display(arr, count);

    return 0;
}