#include <stdio.h>
#include "prac.h"

void add(int arr[], int *count, int item){
    arr[*count] = item;
    (*count)++;
}

void addFront1(int arr[], int *count, int item){
    int i;
    for(i = *count; i > 0; i--)
        arr[i] = arr[i-1];

    arr[0] = item;
    (*count)++;
}

void addFront2(int arr[], int *count, int item){
    int i;
    for(i = (*count)-1; i >= 0; i--)
        arr[i+1] = arr[i];

    arr[0] = item;
    (*count)++;
}

void addAt1(int arr[], int *count, int item, int pos){
    int i;
    for(i = *count; i > pos; i--)
        arr[i] = arr[i-1];

    arr[pos] = item;
    (*count)++;
}

void addAt2(int arr[], int *count, int item, int pos){
    int i;
    for(i = (*count)-1; i >= pos; i--)
        arr[i+1] = arr[i];

    arr[pos] = item;
    (*count)++;
}

void deleteLast(int *count){
    (*count)--;
}

void deleteFront1(int arr[], int *count){
    int i;
    for(i = 0; i < (*count); i++)
        arr[i] = arr[i+1];

    (*count)--;
}

void deleteFront2(int arr[], int *count){
    int i;
    for(i = 1; i < (*count); i++)
        arr[i-1] = arr[i];

    (*count)--;
}

void deleteAt1(int arr[], int *count, int pos){
    int i;
    for(i = pos; i < (*count); i++)
        arr[i] = arr[i+1];
    
    (*count)--;
}

void deleteAt2(int arr[], int *count, int pos){
    int i;
    for(i = pos+1; i < (*count); i++)
        arr[i-1] = arr[i];
    
    (*count)--;
}

void display(int arr[], int count){
    int i;
    for(i = 0; i < count; i++)
        printf("%d ", arr[i]);
    printf("\n");
    printf("-------------\n");
}