#ifndef PRAC_H_
#define PRAC_H_
#define SIZE 5

void add(int arr[], int *count, int item);
void addFront1(int arr[], int *count, int item);
void addFront2(int arr[], int *count, int item);
void addAt1(int arr[], int *count, int item, int pos);
void addAt2(int arr[], int *count, int item, int pos);
void deleteLast(int *count);
void deleteFront1(int arr[], int *count);
void deleteFront2(int arr[], int *count);
void deleteAt1(int arr[], int *count, int pos);
void deleteAt2(int arr[], int *count, int pos);
void display(int arr[], int count);

#endif