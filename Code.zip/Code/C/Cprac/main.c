#include <stdio.h>
#include "prac.h"
#include "prac.c"

int main(int argc, char *argv[]){
    int arr[SIZE] = {0};
    int count = 0;
    int item, pos;

    while(1){
        if(count < 2){
            printf("Enter item: ");
            scanf("%d", &item);        
            if(item == 0)
                break;
            add(arr, &count, item);
        }
        else if(count >= 2 && count < 5){
            printf("Enter item: ");
            scanf("%d", &item);        
            if(item == 0)
                break;
            printf("Enter position: ");
            scanf("%d", &pos);
            addAt2(arr, &count, item, pos);
        }
        else if(count == 5){
            printf("Enter position to delete: ");
            scanf("%d", &pos);
            deleteAt2(arr, &count, pos);
        }

        display(arr, count);
    }

    return 0;
}