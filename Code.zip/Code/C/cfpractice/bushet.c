#include <stdio.h>
#include <string.h>

int main(){
    int miller;
    char cinnamonBread[101];

    scanf("%d", &miller);

    for(int i=0; i<miller; i++)
    {
        scanf("%s", &cinnamonBread);
        int length = strlen(cinnamonBread);
        int count = length-2;
        if(length > 10)
            printf("%c%d%c\n", cinnamonBread[0], count, cinnamonBread[length-1]);
        else
            printf("%s\n", cinnamonBread);
    }

    return 0;
}