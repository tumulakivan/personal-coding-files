#include <stdio.h>
#include <string.h>

void abc(char);

int main(){
    int n, i, j;

    scanf("%d", &n);
    char arr[n][100];

    for(i=0; i<n; i++)
    {
        scanf(" %[^\n]s", arr[i]);
    }

    printf("\n");

    for(i=0; i<n; i++)
    {
        if(arr)

        printf("%c%d%c", arr[i][0], strlen(arr[i])-2, arr[i][strlen(arr[i])-1]);
        printf("\n");
    }


    /*
    for(i=0; i<n; i++)
    {
        for(j = strlen(arr[i])-1; j>=0; j--)
            printf("%c", arr[i][j]);

        printf("\n");
    }
    */

    return 0;
}