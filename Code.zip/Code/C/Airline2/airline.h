void initSeats(int seats[], int size);
void displaySeats(int seats[], int size);
int assignFirstClass(int seats[], int size);
int assignEconomy(int seats[], int size);
int assignSeat(int st[], int seatType);
void boardPass(int seat);