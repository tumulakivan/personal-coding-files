#include <stdio.h>
#include <stdlib.h>
#include "airline.c"
#define SIZE 10

int main(int argc, char *argv[]){
    int seats[SIZE], seatType, seated, cont = 1;
    initSeats(seats, SIZE);

    printf("Welcome to MGM Airlines!\n\n");

    displaySeats(seats, SIZE);

    while(cont = 1){
        printf("Type 1 for First Class, or 2 for Economy: ");
        scanf("%d", &seatType);
        seated = assignSeat(seats, seatType);
        if(seated != -1){
            boardPass(seated);
            displaySeats(seats, SIZE);
        }
        else
            cont--;
            exit(0);
    }

    return 0;
}