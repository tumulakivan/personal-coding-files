#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "airline.h"

void initSeats(int seats[], int size){
    int i;
    for(i = 0; i < size; i++)
        seats[i] = 0;
}

void displaySeats(int seats[], int size){
    int i;
    
    printf("First Class Section: ");
    for(i = 0; i < size/2; i++)
        printf("[%d]", seats[i]);

    printf("\n");

    printf("Economy Section: ");
    for(i = size/2; i < size; i++)
        printf("[%d]", seats[i]);
    
    printf("\n\n");
}

int assignSeat(int seats[], int seatType){
    int seated;
    char option[5];

    if(seatType == 1){
        seated = assignFirstClass(seats, 10);

        if(seated != 1){
            printf("First Class is full. Would you liked to be booked in Economy instead?");
            scanf(" %s", option);

            if(strcmp(option, "Yes") == 0){
                seated = assignEconomy(seats, 10);
                return seated;
            }
            else if(strcmp(option, "No") == 0){
                seated = -1;
                return seated;
            }
        }
        return seated;
    }
}

int assignFirstClass(int seats[], int size){
    int i, seated = -1;
    for(i = 0; i < (size-1)/2; i++){
        if(seats[i] == 0){
            seats[i]++;
            seated = 1;
            break;
        }
    }

    return seated;
}

int assignEconomy(int seats[], int size){
    int i, halfway = ((size-1)/2)+1, seated = -1;
    for(i = size/2; i < size; i++){
        if(seats[i] == 0){
            seats[i]++;
            seated = 1;
            break;
        }
    }

    return seated;
}

void boardPass(int seat){
    printf("\n\nBoarding Pass\n");
    if(seat < 5)
        printf("First Class Section\n");
    else
        printf("Economy Section\n");
    printf("Seat #");
    printf("%d\n\n", seat);
}