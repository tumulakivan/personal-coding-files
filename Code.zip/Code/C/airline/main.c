#include <stdio.h>
#include <string.h>
#include "airline.h"

int main(){

    int seatChoice, seats[10], seatSuccess;
    initSeats(seats, 10);
    printf("Welcome to MGM Airlines!\n");
    displaySeats(seats, 10);
    printf("Please type 1 for \"first class\":\n");
    printf("Please type 2 for \"economy\": ");
    scanf("%d", &seatChoice);  
    seatSuccess = assignSeat(seats, seatChoice);
    if(seatSuccess != -1)
        boardPass(seatSuccess);
    else
        exxit();
    displaySeats(seats, 10);
    printf("\n\n\n\n\n");

    return 0;
}