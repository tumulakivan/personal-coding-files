#include <stdio.h>
#include <string.h>
#include "airline.h"

void initSeats(int seats[], int size){
    
    for(int i = 0; i < size; i++)
        seats[i] = 0;
}

void displaySeats(int seats[], int size){

    int i, halfway = (size-1)/2;
    for(i = 0; i < size; i++)
    {   
        if(i <= halfway)
        {
            if(i == 0)
                printf("First Class Section: [%d] ", seats[i]);
            else
                printf("[%d] ", seats[i]);
        }
        else
        {
            if(i == halfway+1)
                printf("\nEconomy Section: [%d] ", seats[i]);
            else
                printf("[%d] ", seats[i]);
        }
    }
    printf("\n");
}

int assignSeat(int st[], int seatType){
    
    int success;
    char choice[5];
    if(seatType == 1)
    {
        success = assignFirstClass(st, 10);
        if(success == -1)
        {
            printf("Do you want to be placed in the economy section instead? Yes or No?");
            scanf(" %s", choice);
            if(strcmp(choice, "Yes") == 0)
            {
                success = assignEconomy(st, 10);
                return success;
            }
            else if(strcmp(choice, "No") == 0)
                return -1;
        }
    }
    else if(seatType == 2)
        success = assignEconomy(st, 10);

    return success;
}

int assignFirstClass(int seats[], int size){

    int i, halfway = (size-1)/2, success = -1;
    for(i = 0; i <= halfway; i++)
    {
        if(seats[i] == 0)
        {
            seats[i]++;
            success = i;
            break;
        }
    }
    
    return success;
}

int assignEconomy(int seats[], int size){

    int i, halfway = ((size-1)/2)+1, success = -1;
    for(i = halfway; i < size; i++)
    {
        if(seats[i] == 0)
        {
            seats[i]++;
            success = i;
            break;
        }
    }
    
    return success;
}

void boardPass(int seat){

    printf("--------------------------\n");
    printf("| Boarding Pass          |\n");
    if(seat+1 <= 5)
        printf("| First Class Section    |\n");
    else
        printf("| Economy Section        |\n");
    printf("| Seat # %d               |\n", seat+1);
    printf("--------------------------\n");
}

void exxit(void){

    printf("Next flight leaves in 3 hours.\n");
}