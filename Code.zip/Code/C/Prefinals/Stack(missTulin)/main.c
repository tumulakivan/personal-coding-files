#include<stdio.h>
#include<stdlib.h>
#include "stack.h"
int main(){
	Stack *s = createStack();
	
	printf("Peek: %d\n", peek(s));
	push(s,10);
	push(s,20);
	push(s,30);
	printf("Peek: %d\n", peek(s));
	printf("Count: %d\n", s->count);
	printf("Delete Data: %d\n", pop(s));
	printf("Peek: %d\n", peek(s));
	printf("Delete Data: %d\n", pop(s));
	printf("Peek: %d\n", peek(s));
	printf("Delete Data: %d\n", pop(s));
	printf("Peek: %d\n", peek(s));
	printf("Delete Data: %d\n", pop(s));
	printf("Peek: %d\n", peek(s));
}
