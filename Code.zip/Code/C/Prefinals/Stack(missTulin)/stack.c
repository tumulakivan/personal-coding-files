#include<stdio.h>
#include<stdlib.h>
#include "stack.h"

Stack* createStack(){
	Stack *s= (Stack*)malloc(sizeof(Stack));
	s->count=0;
	s->top=NULL;
	return s;
	
}
void push(Stack *s, int data){
	node *newNode;
	
	newNode=(node*) malloc(sizeof(node));
	newNode->data=data;
	newNode->next=s->top;
	s->top=newNode;
	s->count++;
}
int peek(Stack *s){
	if(isEmpty(s)==0)
		return s->top->data;
	return -1;
}

int isEmpty(Stack *s){
	if(s->top==NULL)
		return 1;
	else
		return 0;
}

int pop(Stack *s){
	node *dltPtr;
	int deletedData;
	if(isEmpty(s)==0){
		dltPtr =s->top;
		s->top=s->top->next;
		s->count--;
		dltPtr->next=NULL;
		deletedData = dltPtr->data;
		free(dltPtr);
		return deletedData;
	}
	return -1;
		
	
	
}
