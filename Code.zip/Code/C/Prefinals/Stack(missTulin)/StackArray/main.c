#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	Stack s = createStack();
	
	printf("%d\n",s.top);
	push(&s, 10);
	printf("%d\n", peek(s));
	push(&s, 20);
	printf("%d\n", peek(s));
	push(&s, 30);
	printf("%d\n", peek(s));
	push(&s, 40);
	printf("%d\n", peek(s));
	push(&s, 50);
	printf("%d\n", peek(s));
	push(&s, 60);
	printf("%d\n", peek(s));
	printf("delete data: %d\n",pop(&s));
	printf("%d\n", peek(s));
	return 0;
}
