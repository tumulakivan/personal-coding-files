typedef struct stack{
	int top;
	int data[5];
}Stack;

Stack createStack();
void push(Stack *s, int data);
int peek(Stack s);
int isFull(Stack s);
int isEmpty(Stack s);
int pop(Stack *s);