#include <stdio.h>
#include "pal.h"
#include "pal.c"

int main(){
    char str[SIZE];

    fgets(str, SIZE, stdin);

    size_t len = strlen(str);
    if(len > 0 && str[len-1] == '\n')
        str[len-1] = '\0';

    isPalindrome(str);

    return 0;
}