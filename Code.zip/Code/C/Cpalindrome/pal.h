#ifndef PAL_H_
#define PAL_H_
#define SIZE 100

void isPalindrome(char arr[]);

#endif