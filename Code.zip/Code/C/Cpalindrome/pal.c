#include <stdio.h>
#include <string.h>
#include "pal.h"

void isPalindrome(char str1[]){
    char str2[SIZE];
    int i, y, check = 0;

    for(i = 0, y = strlen(str1)-1; i <  strlen(str1); i++, y--){
        str2[y] = str1[i];
    }

    for(i = 0, y = 0; i< strlen(str1); i++, y++){
        if(str1[i] == str2[y]){
            check++;
        }
    }

    if(check == strlen(str1))
        printf("This word is a palindrome\n");
    else
        printf("This word is not a palindrome\n");
}