#include <stdio.h>
#include "emp.h"
#include "emp.c"

int main(){
    int n;
    double totalGross, totalTax = 0;
    Payrecord roll[100];

    //ask for number of records
    printf("Enter number of records: ");
    scanf("%d", &n);

    //record input
    readRecords(roll, n);
    //calculate
    totalGross = calcRecords(roll, n, &totalTax);
    //output all records
    printRecords(roll, n);
    //print summary
    printSummary(totalGross, totalTax);

    return 0;
}