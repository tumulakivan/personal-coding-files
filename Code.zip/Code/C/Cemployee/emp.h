#ifndef EMP_H_
#define EMP_H_
#define ctr 0

typedef struct{
    char last[15];
    char first[15];
    char middle[15];
}Name;

typedef struct{
    int id;
    Name nameRec;
    float hours, rate;
    float regular, overtime;
    float gross, tax_withheld, net;
}Payrecord;

void readName(Payrecord payRoll[], int i);
void printName(Payrecord payRoll[], int i);
void printSummary(double gross, double tax);
void readRecords(Payrecord payRoll[], int n);
void printRecords(Payrecord payRoll[], int n);
double calcRecords(Payrecord payRoll[], int n, double *taxptr);

#endif