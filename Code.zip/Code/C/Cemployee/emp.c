#include <stdio.h>
#include "emp.h"

void readName(Payrecord payRoll[], int i){
    //input name of specific record
    printf("Last name: ");
    scanf(" %[^\n]", &payRoll[i].nameRec.last);
    printf("First name: ");
    scanf(" %[^\n]", &payRoll[i].nameRec.first);
    printf("Middle Initial: ");
    scanf(" %[^\n]", &payRoll[i].nameRec.middle);
}

void printName(Payrecord payRoll[], int i){
    //output only first element for now
    printf("%s, ", payRoll[i].nameRec.last);
    printf("%s ", payRoll[i].nameRec.first);
    printf("%s.\n", payRoll[i].nameRec.middle);
}

void printSummary(double gross, double tax){
    //total grosspay and tax from all employees
    printf("Total Gross: %.2f\n", gross);
    printf("Total Tax: %.2f", tax);
}

void readRecords(Payrecord payRoll[], int n){
    int i;

    printf("----------------------------------------------\n");
    for(i = 0; i < n; i++){
        printf("Enter Employee ID: ");
        scanf("%d", &payRoll[i].id);
        printf("Enter name below\n");
        readName(payRoll, i);
        printf("Hours worked this week: ");
        scanf("%f", &payRoll[i].hours);
        printf("Hourly rate: ");
        scanf("%f", &payRoll[i].rate);
        printf("----------------------------------------------\n");
    }
    printf("\n");
}

void printRecords(Payrecord payRoll[], int n){
    int i;

    printf("Payroll for this week\n\n");
    printf("----------------------------------------------\n");
    for(i = 0; i < n; i++){
        printf("Employee #%d\n", i+1);
        printf("ID: %d\n", payRoll[i].id);
        printName(payRoll, i);
        printf("Hours: %.2f\n", payRoll[i].hours);
        printf("Rate: %.2f\n", payRoll[i].rate);
        printf("Regular Pay: %.2f\n", payRoll[i].regular);
        printf("Overtime Pay: %.2f\n", payRoll[i].overtime);
        printf("Gross Pay: %.2f\n", payRoll[i].gross);
        printf("Tax: %.2f\n", payRoll[i].tax_withheld);
        printf("Net Pay: %.2f\n", payRoll[i].net);
        printf("----------------------------------------------\n");
    }
}

double calcRecords(Payrecord payRoll[], int n, double *tax){
    double totalGross = 0.0;
    double totalTax = 0.0;
    int i;

    for(i = 0; i < n; i++){
        if(payRoll[i].hours <= 40){
            payRoll[i].regular = payRoll[i].hours * payRoll[i].rate;
            payRoll[i].overtime = 0;
        }
        else{
            payRoll[i].regular = payRoll[i].hours * payRoll[i].rate;
            payRoll[i].overtime = (payRoll[i].hours - 40) * (payRoll[i].rate * 1.5);
        }
        payRoll[i].gross = payRoll[i].regular + payRoll[i].overtime;

        if(payRoll[i].gross < 500)
            payRoll[i].tax_withheld = payRoll[i].gross * 0.15;
        else if(payRoll[i].gross < 1000)
            payRoll[i].tax_withheld = payRoll[i].gross * 0.28;
        else
            payRoll[i].tax_withheld = payRoll[i].gross * 0.33;

        payRoll[i].net = payRoll[i].gross - payRoll[i].tax_withheld;
        totalGross += payRoll[i].gross;
        totalTax += payRoll[i].tax_withheld;
    }

    *tax = totalTax;
    return totalGross;
}