#include "airline.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int checker;

void initSeats(int seats[], int size) {
  	// initializes all seats to 0, or not occupied
  	int i;
  	for (i = 0; i <= size; i++) {
    	seats[i] = 0;
  	}
}

void displaySeats(int seats[], int size) {
  	// displays the status of all seats when called
  	int i;

  	printf("First Class Section: ");
  	for (i = 0; i < size / 2; i++) {
    	printf("[%d]", seats[i]);
  	}
  	printf("\n");

  	printf("Economy Section:     ");
  	for (i = size / 2; i < size; i++) {
    	printf("[%d]", seats[i]);
  	}
  	printf("\n");
}

int assignEconomy(int seats[], int size) {
  	// assigns a seat in economy
  	int i;

  	for (i = size / 2; i < size; i++) {
    	if (seats[i] == 0) {
    		seats[i]++;
			checker++;
      		return i + 1;
    	}
  	}
  	return -1;
}

int assignFirstClass(int seats[], int size) {
  	// assigns a seat in first class
  	int i;

  	for(i = 0; i < size / 2; i++){
    	if (seats[i] == 0) {
      		seats[i]++;
			checker++;
      		return i + 1;
    	}
  	}	
  	return -1;
}

int assignSeat(int seats[], int seatType){
  	// adds a value to seat chosen
  	int seated;
  	char option[5];

  	// switch case for choosing seatType (see main())
  	switch(seatType){
  	case 1:
    	// assigns a seat in first class, if available
    	seated = assignFirstClass(seats, SIZE);

    	if(seated == -1){
    		printf("\nFirst Class is full, would you like to be booked in Economy instead? ");
      		scanf(" %s", option);

      		if (strcmp(option, "yes") == 0){
        		// assigns a seat in economy if first class is full
        		seated = assignEconomy(seats, SIZE);
        		return seated;
      		}

      		else if(strcmp(option, "no")){
        		// seating failed, user opts out of transferring to economy
        		return -1;
      		}
    	}

    	return seated;
    	break;

  	case 2:
    	// assigns a seat in economy
    	seated = assignEconomy(seats, SIZE);

    	if(seated == -1){
      		// economy is full
    		printf("\nEconomy is full, would you like to be booked in First Class instead? ");
    		scanf(" %s", option);

      		if(strcmp(option, "yes") == 0){
        		// assigns a seat in first class if economy is full
        		seated = assignFirstClass(seats, SIZE);
        		return seated;
      		}

      		else if (strcmp(option, "no")) {
        		// seating failed, user opts out of transferring to economy
        		return -1;
      		}
    	}

    	return seated;
    	break;

  	default:
    	printf("Invalid input.");
    	break;
  	}
}

void boardPass(int seat){
  	printf("\n\n|Boarding Pass      |\n");
  	if (seat < 5)
    	printf("|First Class Section|\n");
  	else
    	printf("|Economy Section    |\n");

  	printf("|Seat #%d            |\n\n", seat);
}

void exitMain(){
  	// exit message
  	printf("\nNext flight is in 3 hours.");
}