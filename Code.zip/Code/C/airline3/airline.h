#define SIZE 10
#ifndef AIRLINE_H_
#define AIRLINE_H_

void initSeats(int seats[], int size);
void displaySeats(int seats[], int size);
int assignSeat(int seats[], int seatType);
int assignFirstClass(int seats[], int size);
int assignEconomy(int seats[], int size);
void boardPass(int seat);
void exitMain();

#endif

