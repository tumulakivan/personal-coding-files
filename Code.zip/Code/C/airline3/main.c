#include <stdio.h>
#include <stdlib.h>
#include "airline.h"
#include "airline.c"

/* TUMULAK, IVAN STEIVEN A. */

int main(int argc, char *argv[]) {
	int seats[SIZE], seat, seatType;
	
	printf("Welcome to MGM Airlines!\n\n");
	
	initSeats(seats, SIZE);
	displaySeats(seats, SIZE);
	
	while(checker != SIZE){
		// main loop function
		printf("\n\nType 1 for First Class, | Type 2 for Economy\n");
		scanf("%d", &seatType);
		
		seat = assignSeat(seats, seatType);
		
		if(seat != -1){
			boardPass(seat);
			displaySeats(seats, SIZE);
		}
		else{
			break;
		}
	}

	exitMain();

	return 0;
}

