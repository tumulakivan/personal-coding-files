#include <stdio.h>
#include <string.h>
#include "bank.h"
#include <stdlib.h>

void initializeAcc(struct BankAccount *acc, int accNum, const char *accHolder, float initialBalance){
    acc->accNumber = accNum;
    strcpy(acc->accHolder, accHolder);
    acc->balance = initialBalance;
}

void deposit(struct BankAccount *acc, float amount){
    acc->balance += amount;
    printf("Added Php %.2f to balance.\n\n", amount);
}

void withdraw(struct BankAccount *acc, float amount){
    if(amount <= acc->balance){
        acc->balance -= amount;
        printf("Withdrew Php %.2f from balance.\n\n", amount);
    }
    else
        printf("Not enough funds.\n\n");
}

void status(const struct BankAccount *acc){
    printf("Account Number: %d\n", acc->accNumber);
    printf("%s", acc->accHolder);
    printf("\n");
    printf("Balance: Php %.2f\n", acc->balance);
}