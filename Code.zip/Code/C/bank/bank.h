#ifndef BANK_H_
#define BANK_H_

struct BankAccount{
    int accNumber;
    char accHolder[100];
    float balance;
};

void initializeAcc(struct BankAccount *acc, int accNum, const char *accHolder, float initialBalance);
void deposit(struct BankAccount *acc, float amount);
void withdraw(struct BankAccount *acc, float amount);
void status(const struct BankAccount *acc);

#endif