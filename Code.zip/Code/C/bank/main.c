#include <stdio.h>
#include <string.h>
#include "bank.h"
#include "bank.c"

int main(int argc, char *argv[]){
    struct BankAccount bank;
    int id, choice;
    float amount;
    char name[100];

    printf("Enter ID: ");
    scanf("%d", &id);
    printf("Enter Account Name: ");
    scanf(" %[^\n]", name);
    printf("Initial Balance: Php ");
    scanf("%f", &amount);
    printf("\n");
    initializeAcc(&bank, id, name, amount);

    while(1){
        printf("Please select operation\n\n");
        printf("1.) View account details\n");
        printf("2.) Withdraw\n");
        printf("3.) Deposit\n");
        printf("4.) Exit\n");
        scanf("%d", &choice);
        
        if(choice == 4){
            printf("\nThank you for banking with us!");
            break;
        }
        else if(choice == 1){
            printf("\n");
            status(&bank);
        }
        else if(choice == 2){
            printf("\n");
            printf("Please enter desired amount: ");
            scanf("%f", &amount);
            withdraw(&bank, amount);
        }
        else if(choice == 3){
            printf("\n");
            printf("Please enter desired amount: ");
            scanf("%f", &amount);
            deposit(&bank, amount);
        }
        else
            printf("Invalid input!\n\n");
    }

    return 0;
}