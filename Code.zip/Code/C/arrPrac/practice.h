void display(int arr[]);
int highest(int arr[]);
int lowest(int arr[]);
float mid(int arr[]);
int secondHighest(int arr[]);