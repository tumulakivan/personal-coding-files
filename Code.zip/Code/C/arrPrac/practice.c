#include <stdio.h>
#include <stdlib.h>
#include "practice.h"
#define size 6

void display(int arr[]){
	int i;
	for(i=0; i<size; i++)
		printf("%d ", arr[i]);
}

void initArray(int arr[]){
	int i;
	for(i=0; i<size; i++)
		arr[i]=0;
}

int highest(int arr[]){
	int high = arr[0];
	int i;
	for(i=1; i<size; i++){
		if(high < arr[i])
			high = arr[i];
	}
	
	display(arr);
	return high;
}

int lowest(int arr[]){
	int low = arr[0];
	int i;
	for(i=1; i<size; i++){
		if(low > arr[i])
			low = arr[i];
	}
	
	display(arr);
	return low;
}

float mid(int arr[]){	
	int center = (size/2)-1, center2 = (center+1);
	
	printf("%d, %d", arr[center], arr[center2]);
	
	if(size%2==0)
		return (arr[center]+arr[center2])/2.00;
	else
		return arr[center];
}

int secondHighest(int arr[]){
	int i = 0, high = highest(arr), sec = arr[0];

	while(arr[i]<high){
		if(arr[i]>sec)
			sec = arr[i];
		
		i++;
	}
	
	return sec;
}