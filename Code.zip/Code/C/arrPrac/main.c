#include <stdio.h>
#include <stdlib.h>
#include "practice.c"
#define size 6

int main(int argc, char *argv[])
{
	int array[10], i;
	initArray(array);
	display(array);
	printf("\n");
		
	for(i=0; i<size; i++)
		scanf("%d", &array[i]);
		
	printf(" | %d\n", highest(array));
	printf(" | %d\n", lowest(array));
	printf(" | %.2f\n", mid(array));
	printf(" | %d\n", secondHighest(array));
}