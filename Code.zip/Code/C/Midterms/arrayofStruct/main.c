#include <stdio.h>
#include "arrofs.h"

int main(int argc, char *argv[])
{
    int count = 2;
    Items items[MAX] = {{1, "Mouse", 12}, {2, "HDMI", 50}};

    display(items, count);
    add(items, 3, "RJ", 100, &count);
    display(items, count);
    add(items, 4, "Keyboard", 20, &count);
    display(items, count);
    add(items, 5, "RAM", 16, &count);
    display(items, count);
    add(items, 6, "GPU", 5, &count);
    printf("\n\n");
    display(items, count);

    return 0;
}