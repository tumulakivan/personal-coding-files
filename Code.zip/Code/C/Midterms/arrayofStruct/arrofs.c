#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "arrofs.h"

void add(Items items[], int id, char name[], int qty, int *count)
{
    int i;

    if ((*count) >= MAX)
    {
        printf("Array is full\n");
        return;
    }
    else
    {
        for (i = 0; i < (*count); i++)
        {
            if (items[i].id == id)
            {
                printf("Item already exists\n\n");
                return;
            }
        }
    }

    items[*count].id = id;
    strcpy(items[*count].name, name);
    items[*count].qty = qty;
    (*count)++;
}

void display(Items items[], int count)
{
    int i;

    for (i = 0; i < count; i++)
    {
        printf("Id: %d\n", items[i].id);
        printf("Name: %s\n", items[i].name);
        printf("Qty: %d\n\n", items[i].qty);
    }
}