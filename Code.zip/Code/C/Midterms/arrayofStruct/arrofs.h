#ifndef ARROFS_H_
#define ARROFS_H_
#define MAX 5

typedef struct
{
    int id;
    char name[20];
    int qty;
} Items;

void add(Items items[], int id, char name[], int qty, int *count);
void display(Items items[], int count);

#endif