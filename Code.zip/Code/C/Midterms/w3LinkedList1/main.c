#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
    int data;
    struct Node *next;
} Node;

Node *createNode(int data)
{
    Node *newNode = (Node *)malloc(sizeof(Node));
    if (newNode == NULL)
    {
        fprintf(stderr, "malloc failed\n");
        exit(1);
    }

    newNode->data = data;
    newNode->next = NULL;

    return newNode;
}

void appendNode(Node **head, int data)
{
    Node *newNode = createNode(data);
    if (*head == NULL)
        *head = newNode;
    else
    {
        Node *curr = *head;
        while (curr->next != NULL)
            curr = curr->next;
        curr->next = newNode;
    }
}

int main()
{
    Node *head = NULL;
    int max, num, i;

    printf("Input the number of nodes: ");
    scanf("%d", &max);

    printf("\n");

    for (i = 0; i < max; i++)
    {
        printf("Input data for node %d: ", i + 1);
        scanf("%d", &num);
        appendNode(&head, num);
    }

    printf("\n");

    printf("Data entered in the list:\n");
    Node *curr = head;
    while (curr != NULL)
    {
        printf("Data = %d\n", curr->data);
        curr = curr->next;
    }

    return 0;
}