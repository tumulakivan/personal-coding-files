#ifndef PRELIM_H_
#define PRELIM_H_
#define SIZE 5

void initArray(int arr[]);
void display(int arr[]);
void reverse(int arr[]);
void doubleAndCopy(int arrA[], int arrB[]);
int countDuplicate(int array[]);
int findMax(int arr[]);
float average(int arr[]);

#endif