#include <stdio.h>
#include <stdlib.h>
#include "prelim.h"

void initArray(int arr[]){
    int i;

    printf("Enter array elements here:\n");

    for(i = 0; i < SIZE; i++)
        scanf("%d", &arr[i]);
}

void display(int arr[]){
    int i;

    for(i = 0; i < SIZE; i++)
        printf("%d ", arr[i]);

    printf("\n");
}

void reverse(int arr[]){
    int i, temp, last = SIZE - 1;

    for(i = 0; i < SIZE/2; i++){
        temp = arr[i];
        arr[i] = arr[last-i];
        arr[last-i] = temp;
    }

    display(arr);
}

void doubleAndCopy(int arrA[], int arrB[]){
    int i;
    
    for(i = 0; i < SIZE; i++)
        arrB[i] = arrA[i] * 2;
}

int countDuplicate(int array[]){
    int count = 0, i, j;

    for(i = 0; i < SIZE; i++){
        for(j = i + 1; j < SIZE; j++){
            //check if arr[i] == arr[j] for duplicates
            //this checks every element of the array
            if(array[i] == array[j]){
                count++;
                break;
            }
        }
    }

    return count;
}

int findMax(int arr[]){
    int i, highest = arr[0];

    for(i = 1; i < SIZE; i++){
        if(arr[i] > highest)
            highest = arr[i];
    }

    return highest;
}

float average(int arr[]){
    int i, total = 0;

    for(i = 0; i < SIZE; i++)
        total += arr[i];

    return (float)total / SIZE;
}