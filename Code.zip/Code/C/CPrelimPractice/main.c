#include <stdio.h>
#include <stdlib.h>
#include "prelim.h"
#include "prelim.c"

int main(int argc, char *argv[]){
    int array[SIZE], xtrArr[SIZE], dupe, max;
    float avg;

    printf("~Doubling the first array~\n");
    initArray(array);
    doubleAndCopy(array, xtrArr);
    display(xtrArr);
    printf("\n");

    printf("~Checking for duplicates~\n");
    initArray(array);
    dupe = countDuplicate(array);
    printf("Duplicates: %d", dupe);
    printf("\n\n");

    printf("~Finding highest value~\n");
    initArray(array);
    max = findMax(array);
    printf("Highest value: %d", max);
    printf("\n\n");

    printf("~Finding average~\n");
    initArray(array);
    avg = average(array);
    printf("Average: %.2f", avg);
    printf("\n\n");

    printf("~Reversing the entire array~\n");
    initArray(array);
    printf("The array with reversed indices: ");
    reverse(array);

    return 0;
}