#include <stdio.h>
#include "table.h"

void display(int arr[][COL]){
    int i, j;
    
    for(i = 0; i < ROW; i++){
        for(j = 0; j < COL; j++){
            printf("%6d", arr[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    printf("\n");
}


void mtTable(int arr[][COL]){
    int i, j;
    for(i = 0; i < ROW; i++){
        for(j = 0; j < COL; j++)
            printf("%6d", (i+1)*(j+1));
        printf("\n");
    }
    printf("\n");
    printf("\n");
}

void initTable1(int arr[][COL]){
    int i, j, a = 1;
    
    printf("First matrix:\n");
    for(i = 0; i < ROW; i++){
        for(j = 0; j < COL; j++){
            arr[i][j] = a;
            a++;
        }
    }

    display(arr);
}

void initTable2(int arr[][COL]){
    int i, j, a = 2;
    
    printf("Second matrix:\n");
    for(i = 0; i < ROW; i++){
        for(j = 0; j < COL; j++){
            arr[i][j] = a;
            a++;
        }
    }

    display(arr);
}

void addTable(int arr[][COL], int mx1[][COL], int mx2[][COL]){
    int i, j;

    printf("Sum of first and second matrix:\n");
    for(i = 0; i < ROW; i++){
        for(j = 0; j < COL; j++){
            arr[i][j] = mx1[i][j] + mx2[i][j];
        }
    }

    display(arr);
}

void subTable(int arr[][COL], int mx1[][COL], int mx2[][COL]){
    int i, j;

    printf("Difference of first and second matrix:\n");
    for(i = 0; i < ROW; i++){
        for(j = 0; j < COL; j++){
            arr[i][j] = mx1[i][j] - mx2[i][j];
        }
    }

    display(arr);
}

void mtplyTable(int arr[][COL], int mx1[][COL], int mx2[][COL]){
    int i, j, result = 0;

    printf("Sum of the products of each row:\n");
    for(i = 0; i < ROW; i++){

        for(j = 0; j < COL; j++){
            arr[i][j] = mx1[i][j] * mx2[i][j];
        }
    }

    display(arr);

    for(i = 0; i < ROW; i++){
        for(j = 0; j < COL; j++){
            result += arr[i][j];
        }
        printf("Sum of row %d: %d\n", i+1, result);
        result = 0;
    }
}