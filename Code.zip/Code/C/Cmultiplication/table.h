#ifndef TABLE_H_
#define TABLE_H_
#define ROW 6
#define COL 6

void display(int arr[][COL]);
void mtTable(int arr[][COL]);
void initTable1(int arr[][COL]);
void initTable2(int arr[][COL]);
void addTable(int arr[][COL], int mx1[][COL], int mx2[][COL]);
void subTable(int arr[][COL], int mx1[][COL], int mx2[][COL]);
void mtplyTable(int arr[][COL], int mx1[][COL], int mx2[][COL]);

#endif