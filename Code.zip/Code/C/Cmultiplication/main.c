#include <stdio.h>
#include "table.h"
#include "table.c"

int main(){
    int arr[ROW][COL], arr1[ROW][COL], arr2[ROW][COL], 
    fArr[ROW][COL], row, col;

    mtTable(arr);

    initTable1(arr1);
    initTable2(arr2);

    addTable(fArr, arr1, arr2);
    subTable(fArr, arr1, arr2);
    mtplyTable(fArr, arr1, arr2);

    return 0;
}